package main

import (
	"encoding/json"
	"net/http"
	"testing"

	"greenlight.bcc/internal/assert"
)

func TestCreateToken(t *testing.T) {
	testApplication := newTestApplication(t)
	server := newTestServer(t, testApplication.routesTest())
	defer server.Close()

	const (
		validEmail                      = "test0@test.com"
		validPassword                   = "TestPassword"
		emailInvalidCredentials         = "test1@test.com"
		emailInternalServerErr          = "test2@test.com"
		invalidPasswordEmail            = "test3@test.com"
		invalidCredentialsPasswordEmail = "test4@test.com"
		tokenErrorEmail                 = "test5@test.com"
	)

	tests := []struct {
		name     string
		Email    string
		Password string
		wantCode int
	}{
		{
			name:     "Create token",
			Email:    validEmail,
			Password: validPassword,
			wantCode: http.StatusCreated,
		},
		{
			name:     "InvalidCredentials after	GetByEmail",
			Email:    emailInvalidCredentials,
			Password: validPassword,
			wantCode: http.StatusUnauthorized,
		},
		{
			name:     "InternalServerError after GetByEmail",
			Email:    emailInternalServerErr,
			Password: validPassword,
			wantCode: http.StatusInternalServerError,
		},
		{
			name:     "Email validation fail",
			Email:    "invalid",
			Password: validPassword,
			wantCode: http.StatusUnprocessableEntity,
		},
		{
			name:     "Invalid password",
			Email:    invalidPasswordEmail,
			Password: validPassword,
			wantCode: http.StatusInternalServerError,
		},
		{
			name:     "InvalidCredentials password",
			Email:    invalidCredentialsPasswordEmail,
			Password: "aaaaaaaa",
			wantCode: http.StatusUnauthorized,
		},
		{
			name:     "token error",
			Email:    tokenErrorEmail,
			Password: validPassword,
			wantCode: http.StatusInternalServerError,
		},
		{
			name:     "Fake json.Write",
			Email:    validEmail,
			Password: validPassword,
			wantCode: http.StatusInternalServerError,
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {

			if test.name == "Fake json.Write" {
				storedMarshal := jsonMarshal
				jsonMarshal = server.fakeMarshal
				defer server.restoreMarshal(storedMarshal)
			}

			inputData := struct {
				Email    string `json:"email"`
				Password string `json:"password"`
			}{
				Email:    test.Email,
				Password: test.Password,
			}

			b, err := json.Marshal(&inputData)
			if err != nil {
				t.Fatal("wrong input data")
			}
			if test.name == "test for wrong input" {
				b = append(b, 'a')
			}

			code, _, _ := server.postForm(t, "/v1/tokens/authentication", b)

			assert.Equal(t, code, test.wantCode)
		})
	}

	header, _, _ := server.postForm(t, "/v1/tokens/authentication", []byte{})

	assert.Equal(t, header, http.StatusBadRequest)
}
