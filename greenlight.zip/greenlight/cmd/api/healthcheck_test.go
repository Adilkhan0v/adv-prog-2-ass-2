package main

import (
	"net/http"
	"testing"
)

func TestHealthcheck(t *testing.T) {
	testApplication := newTestApplication(t)
	server := newTestServer(t, testApplication.routes())
	defer server.Close()

	for i := 0; i < 2; i++ {
		if i == 1 {
			storedMarshal := jsonMarshal
			jsonMarshal = server.fakeMarshal
			defer server.restoreMarshal(storedMarshal)
		}
		header, _, _ := server.get(t, "/v1/healthcheck")

		if i == 0 && header != http.StatusOK {
			t.Errorf("want %d; got %d", http.StatusOK, header)
		}
		if i == 1 && header != http.StatusInternalServerError {
			t.Errorf("want %d; got %d", http.StatusOK, header)
		}
	}
}
